from django.http.request import QueryDict
from django.http.response import HttpResponse
from django.shortcuts import render, redirect
from .models import Question


def quest(request):
    question = Question.objects.all()
    return render(request, 'quest/quest.html', {'title': 'Создание вопросов', 'question': question})
 