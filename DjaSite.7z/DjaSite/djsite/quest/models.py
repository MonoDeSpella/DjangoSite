from django.db import models


class Question(models.Model):
    title = models.CharField('Вопрос:', max_length=50)
    var1 = models.CharField('Вариант 1:', max_length=50)
    var2 = models.CharField('Вариант 2:', max_length=50)
    var3 = models.CharField('Вариант 3:', max_length=50)
    rightIs = models.CharField('Верный:', max_length=50)

    def __str__(self):
        return self.title  

    class Meta():
        verbose_name = 'Вопрос'
        verbose_name_plural = 'Вопросы'  